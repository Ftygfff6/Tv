package com.local.gtar;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.TextView;

/**
 * نسخة اختبار: كل 4 ثوانٍ تلتقط الشاشة وتعرض نصاً عربياً أسفلها يبيّن
 * هل الالتقاط يعمل فوق PS Remote Play أم تظهر اللقطة سوداء.
 */
public class TranslatorService extends AccessibilityService {

    private static final long INTERVAL_MS = 4000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private TextView overlay;
    private boolean running = false;
    private int shots = 0;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            capture();
            handler.postDelayed(this, INTERVAL_MS);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createOverlay();
        show("تم تشغيل الخدمة. سيبدأ اختبار التقاط الشاشة بعد لحظات…");
        running = true;
        handler.postDelayed(tick, 2500);
    }

    private void createOverlay() {
        overlay = new TextView(this);
        overlay.setTextSize(30);
        overlay.setTextColor(Color.WHITE);
        overlay.setBackgroundColor(0xCC000000);
        overlay.setPadding(40, 20, 40, 20);
        overlay.setGravity(Gravity.CENTER);
        overlay.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        overlay.setTextDirection(View.TEXT_DIRECTION_RTL);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        params.y = 60;
        windowManager.addView(overlay, params);
    }

    private void show(String text) {
        if (overlay != null) overlay.setText(text);
    }

    private void capture() {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override
                public void onSuccess(ScreenshotResult result) {
                    handleShot(result);
                }

                @Override
                public void onFailure(int errorCode) {
                    show("فشل التقاط الشاشة. رمز الخطأ: " + errorCode + " (" + errorName(errorCode) + ")");
                }
            });
        } catch (Throwable t) {
            show("خطأ: " + t);
        }
    }

    private void handleShot(ScreenshotResult result) {
        HardwareBuffer buffer = result.getHardwareBuffer();
        Bitmap hardware = null;
        Bitmap soft = null;
        Bitmap small = null;
        try {
            hardware = Bitmap.wrapHardwareBuffer(buffer, result.getColorSpace());
            if (hardware == null) {
                show("تعذر قراءة اللقطة.");
                return;
            }
            int width = hardware.getWidth();
            int height = hardware.getHeight();
            soft = hardware.copy(Bitmap.Config.ARGB_8888, false);
            if (soft == null) {
                show("تعذر نسخ اللقطة للمعالجة.");
                return;
            }
            small = Bitmap.createScaledBitmap(soft, 64, 36, true);

            // نقيس الجزء العلوي فقط (60%) حتى لا يتأثر القياس بشريط النص في الأسفل.
            int rows = (int) (small.getHeight() * 0.6);
            int count = 0;
            int bright = 0;
            for (int y = 0; y < rows; y++) {
                for (int x = 0; x < small.getWidth(); x++) {
                    int p = small.getPixel(x, y);
                    int lum = (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000;
                    count++;
                    if (lum > 12) bright++;
                }
            }
            int percent = count == 0 ? 0 : bright * 100 / count;
            shots++;

            if (percent < 2) {
                show("تنبيه: اللقطة رقم " + shots + " سوداء تقريباً (" + width + "×" + height + ").\n"
                        + "إما أن Remote Play يمنع الالتقاط أو أن المشهد مظلم. جرّب مشهداً مضيئاً.");
            } else {
                show("نجح: التقاط الشاشة يعمل! اللقطة رقم " + shots + " (" + width + "×" + height + ").\n"
                        + "نسبة المناطق المضيئة: " + percent + "%");
            }
        } catch (Throwable t) {
            show("خطأ أثناء المعالجة: " + t);
        } finally {
            if (small != null) small.recycle();
            if (soft != null) soft.recycle();
            if (hardware != null) hardware.recycle();
            if (buffer != null) buffer.close();
        }
    }

    private String errorName(int code) {
        switch (code) {
            case 1: return "خطأ داخلي";
            case 2: return "الخدمة ليس لها صلاحية الالتقاط";
            case 3: return "الفاصل بين اللقطات قصير";
            case 4: return "شاشة غير صالحة";
            default: return "غير معروف";
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // غير مستخدم في نسخة الاختبار.
    }

    @Override
    public void onInterrupt() {
        // غير مستخدم في نسخة الاختبار.
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        if (overlay != null && windowManager != null) {
            try {
                windowManager.removeView(overlay);
            } catch (Exception ignored) {
                // الواجهة محذوفة أصلاً.
            }
        }
        super.onDestroy();
    }
}
