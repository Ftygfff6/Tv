package com.local.gtar;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(80, 60, 80, 60);
        root.setBackgroundColor(Color.parseColor("#141518"));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView text = new TextView(this);
        text.setTextSize(26);
        text.setTextColor(Color.WHITE);
        text.setLineSpacing(0, 1.3f);
        text.setTextDirection(View.TEXT_DIRECTION_RTL);
        text.setText("اختبار مترجم الألعاب\n\n"
                + "1) اضغط الزر أدناه وفعّل خدمة «مترجم الألعاب» من إعدادات إمكانية الوصول.\n"
                + "2) افتح PS Remote Play وابدأ اللعب.\n"
                + "3) كل 4 ثوانٍ يظهر في أسفل الشاشة نص عربي يبيّن هل التقاط الشاشة يعمل.");
        root.addView(text);

        Button button = new Button(this);
        button.setText("فتح إعدادات إمكانية الوصول");
        button.setTextSize(24);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                } catch (ActivityNotFoundException e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            }
        });
        root.addView(button);

        setContentView(root);
        button.requestFocus();
    }
}
