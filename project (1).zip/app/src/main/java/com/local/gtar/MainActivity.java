package com.local.gtar;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int REQ_CAPTURE = 1001;

    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(80, 40, 80, 40);
        root.setBackgroundColor(Color.parseColor("#141518"));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView text = new TextView(this);
        text.setTextSize(24);
        text.setTextColor(Color.WHITE);
        text.setLineSpacing(0, 1.3f);
        text.setTextDirection(View.TEXT_DIRECTION_RTL);
        text.setText("اختبار مترجم الألعاب (نسخة 0.2)\n\n"
                + "1) اسمح بالعرض فوق التطبيقات (إن لم تظهر الشاشة تجاهل هذه الخطوة).\n"
                + "2) اضغط «بدء التقاط الشاشة» ووافق على رسالة النظام.\n"
                + "3) افتح PS Remote Play. كل 4 ثوانٍ يظهر نص عربي أسفل الشاشة يبيّن هل الالتقاط يعمل.");
        root.addView(text);

        Button overlayButton = new Button(this);
        overlayButton.setText("1) السماح بالعرض فوق التطبيقات");
        overlayButton.setTextSize(22);
        overlayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openOverlaySettings();
            }
        });
        root.addView(overlayButton);

        Button startButton = new Button(this);
        startButton.setText("2) بدء التقاط الشاشة");
        startButton.setTextSize(22);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestCapture();
            }
        });
        root.addView(startButton);

        Button stopButton = new Button(this);
        stopButton.setText("إيقاف");
        stopButton.setTextSize(22);
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, CaptureService.class));
                status.setText("تم الإيقاف.");
            }
        });
        root.addView(stopButton);

        status = new TextView(this);
        status.setTextSize(22);
        status.setTextColor(Color.parseColor("#F5B83D"));
        status.setTextDirection(View.TEXT_DIRECTION_RTL);
        status.setPadding(0, 24, 0, 0);
        status.setText(Settings.canDrawOverlays(this)
                ? "صلاحية العرض فوق التطبيقات: مفعّلة."
                : "صلاحية العرض فوق التطبيقات: غير مفعّلة (ستظهر النتيجة كرسالة مؤقتة).");
        root.addView(status);

        setContentView(root);
        startButton.requestFocus();
    }

    private void openOverlaySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } catch (ActivityNotFoundException e) {
            status.setText("هذا التلفزيون لا يعرض شاشة صلاحية العرض فوق التطبيقات. ستظهر النتيجة كرسالة مؤقتة.");
        }
    }

    private void requestCapture() {
        try {
            MediaProjectionManager manager =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE);
        } catch (ActivityNotFoundException e) {
            status.setText("هذا التلفزيون لا يدعم التقاط الشاشة (لا توجد شاشة إذن النظام).");
        } catch (Throwable t) {
            status.setText("تعذر طلب إذن الالتقاط: " + t);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, CaptureService.class);
            service.putExtra("code", resultCode);
            service.putExtra("data", data);
            startForegroundService(service);
            status.setText("بدأ الالتقاط. ارجع إلى Remote Play وراقب النص أسفل الشاشة.");
        } else {
            status.setText("تم رفض إذن التقاط الشاشة أو إلغاؤه.");
        }
    }
}
