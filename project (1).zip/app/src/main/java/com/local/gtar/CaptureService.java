package com.local.gtar;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.ByteBuffer;

/**
 * نسخة اختبار: كل 4 ثوانٍ تلتقط الشاشة بواجهة MediaProjection (بدون إمكانية الوصول)
 * وتعرض نصاً عربياً أسفلها يبيّن هل الالتقاط يعمل فوق PS Remote Play أم تظهر اللقطة سوداء.
 */
public class CaptureService extends Service {

    private static final String CHANNEL_ID = "gtar_capture";
    private static final long INTERVAL_MS = 4000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private WindowManager windowManager;
    private TextView overlay;
    private boolean running = false;
    private int shots = 0;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            analyze();
            handler.postDelayed(this, INTERVAL_MS);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) return START_NOT_STICKY;
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        startAsForeground();

        int code = intent != null ? intent.getIntExtra("code", 0) : 0;
        Intent data = intent != null ? (Intent) intent.getParcelableExtra("data") : null;
        if (data == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            MediaProjectionManager manager =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(code, data);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopSelf();
                }
            }, handler);
            startCapture();
            running = true;
            showText("بدأ الالتقاط. سيظهر أول اختبار بعد لحظات…");
            handler.postDelayed(tick, 3000);
        } catch (Throwable t) {
            showText("فشل بدء الالتقاط: " + t);
        }
        return START_NOT_STICKY;
    }

    private void startAsForeground() {
        NotificationManager manager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.createNotificationChannel(
                new NotificationChannel(CHANNEL_ID, "التقاط الشاشة", NotificationManager.IMPORTANCE_LOW));
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("مترجم الألعاب")
                .setContentText("جارٍ التقاط الشاشة")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, notification);
        }
    }

    private void startCapture() {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int width = Math.max(2, metrics.widthPixels / 2);
        int height = Math.max(2, metrics.heightPixels / 2);
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        virtualDisplay = projection.createVirtualDisplay(
                "gtar", width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, handler);
    }

    private void analyze() {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) {
                showText("لا توجد لقطة بعد. انتظر لحظة…");
                return;
            }
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            int width = image.getWidth();
            int height = image.getHeight();

            // نقيس الجزء العلوي فقط (60%) حتى لا يتأثر القياس بشريط النص في الأسفل.
            int rows = (int) (height * 0.6);
            int stepX = Math.max(1, width / 64);
            int stepY = Math.max(1, rows / 21);
            int count = 0;
            int bright = 0;
            for (int y = 0; y < rows; y += stepY) {
                for (int x = 0; x < width; x += stepX) {
                    int offset = y * rowStride + x * pixelStride;
                    if (offset + 2 >= buffer.limit()) continue;
                    int r = buffer.get(offset) & 0xFF;
                    int g = buffer.get(offset + 1) & 0xFF;
                    int b = buffer.get(offset + 2) & 0xFF;
                    int lum = (r * 299 + g * 587 + b * 114) / 1000;
                    count++;
                    if (lum > 12) bright++;
                }
            }
            int percent = count == 0 ? 0 : bright * 100 / count;
            shots++;

            if (percent < 2) {
                showText("تنبيه: اللقطة رقم " + shots + " سوداء تقريباً (" + width + "×" + height + ").\n"
                        + "إما أن Remote Play يمنع الالتقاط أو أن المشهد مظلم. جرّب مشهداً مضيئاً.");
            } else {
                showText("نجح: التقاط الشاشة يعمل! اللقطة رقم " + shots + " (" + width + "×" + height + ").\n"
                        + "نسبة المناطق المضيئة: " + percent + "%");
            }
        } catch (Throwable t) {
            showText("خطأ أثناء المعالجة: " + t);
        } finally {
            if (image != null) image.close();
        }
    }

    private void showText(String text) {
        if (Settings.canDrawOverlays(this)) {
            if (overlay == null) createOverlay();
            if (overlay != null) {
                overlay.setText(text);
                return;
            }
        }
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    private void createOverlay() {
        try {
            TextView view = new TextView(this);
            view.setTextSize(30);
            view.setTextColor(Color.WHITE);
            view.setBackgroundColor(0xCC000000);
            view.setPadding(40, 20, 40, 20);
            view.setGravity(Gravity.CENTER);
            view.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            view.setTextDirection(View.TEXT_DIRECTION_RTL);

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            params.y = 60;
            windowManager.addView(view, params);
            overlay = view;
        } catch (Throwable t) {
            overlay = null;
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        if (virtualDisplay != null) virtualDisplay.release();
        if (reader != null) reader.close();
        if (projection != null) {
            try {
                projection.stop();
            } catch (Throwable ignored) {
                // الإسقاط متوقف أصلاً.
            }
        }
        if (overlay != null && windowManager != null) {
            try {
                windowManager.removeView(overlay);
            } catch (Throwable ignored) {
                // الواجهة محذوفة أصلاً.
            }
        }
        super.onDestroy();
    }
}
